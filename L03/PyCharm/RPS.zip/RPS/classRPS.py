from time import time
import random as r
import logging as log

mvs={0:'R',1:'P',2:'S'}
r.seed(time()*1000)

def valid(playerinput):
    if str(playerinput)=='R' or str(playerinput)=='S' or str(playerinput)=='P':
        return True
    else:
        print('Not a valid move!!!')
        return False

#Construct Logger
logger=log.getLogger('RPS_LOGGER')
logger.setLevel(log.DEBUG)
sh=log.StreamHandler()
fh=log.FileHandler('RPS.log')
formatter=log.Formatter('%(asctime)s--%(levelname)s-%(message)')
sh.setFormatter(formatter)
fh.setFormatter(formatter)
logger.addHandler(sh)
logger.addHandler(fh)


class rps:
    def __init__(self):
        self.computerwins=0
        self.playerwins=0
        self.playermove=''
        self.computermove=''

    def standard_moves(self,ply,cmp):
         self.playermove=ply
         self.computermove=cmp
         if str(ply)==str(cmp):
             return
         elif (str(ply)=='R' and str(cmp)=='S') or (str(ply)=='S' and str(cmp)=='P') or (str(ply)=='P' and str(cmp)=='R'):
             self.playerwins+=1
         else:
             self.computerwins+=1

    def winner(self):
        if str(self.playermove)==str(self.computermove):
            return
        elif str(self.playermove)=='R' and str(self.computermove)=='S':
             self.playerwins+=1
        elif str(self.playermove)=='P' and str(self.computermove)=='R':
             self.playerwins+=1
        elif str(self.playermove)=='S' and str(self.computermove)=='P':
             self.playerwins+=1
        else:
            self.computerwins+=1

    def rounds(self):
        ran=input('Give Number of rounds:')
        for i in range(int(ran)):
            x=r.randint(0,2)
            self.computermove=mvs[int(x)]
            self.playermove=input('Give move(R/P/S):')
            self.playermove=self.playermove.upper()
            logger.info('Player Move:'+str(self.playermove))
            return
            while not valid(self.playermove):
                logger.info('Player Move:' + str(self.playermove)+' is not valid')
                self.playermove=input('Give move(R/P/S):')
                self.playermove=self.playermove.upper()
            self.winner()
    
    def display(self):
        print('Player Wins:'+str(self.playerwins)+'\tComputerWins:'+str(self.computerwins))
    
    def __str__(self):
       return 'Player Wins:'+str(self.playerwins)+'\tComputerWins:'+str(self.computerwins)

def main():
    rpsobject=rps()
    rpsobject.rounds()
    print(rpsobject)
