import classRPS

classRPS.main()