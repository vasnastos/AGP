// logger example using dependency injection
