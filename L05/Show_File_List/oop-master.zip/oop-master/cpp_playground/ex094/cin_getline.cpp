#include <iostream>

using namespace std;

int main()
{
    string s;
    cout << "enter input with spaces: ";
    getline(cin, s);
    cout << s;
}

/*
enter input with spaces: text with spaces as input
text with spaces as input
*/