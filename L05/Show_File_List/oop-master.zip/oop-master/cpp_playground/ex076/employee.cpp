#include "employee.hpp"

std::string employee::get_name(){
    return name;
}

double employee::get_salary(){
    return salary;
}

void employee::set_salary(double sal){
    salary=sal;
}

