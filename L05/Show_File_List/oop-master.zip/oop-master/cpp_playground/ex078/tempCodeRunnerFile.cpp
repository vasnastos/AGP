ouble get_balance()
    {
        return balance;
    }