template <>
// char *max<char *>(char *a, char *b)
// {
//     if (strcmp(a, b) > 0)
//     {
//         return a;
//     }
//     else
//     {
//         return b;
//     }
// }