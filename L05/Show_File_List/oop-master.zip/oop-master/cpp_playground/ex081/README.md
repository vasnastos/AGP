# Παράδειγμα με constructors/destructors

Κλάση Address με πεδία: street, city, postal_code 
Κλάση Person με πεδία: name, age, *Address

    $ g++ person.cpp main.cpp -o main -std=c++11
    $ ./main