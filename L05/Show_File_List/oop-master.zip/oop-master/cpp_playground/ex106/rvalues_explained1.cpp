// http://thbecker.net/articles/rvalue_references/section_01.html
