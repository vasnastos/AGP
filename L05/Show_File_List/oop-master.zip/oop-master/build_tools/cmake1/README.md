# CMAKE example

    ```
    |
    --bin
    --src
       |
       -- CMakeLists.txt
       -- hello.cpp 

    ```
    $ cd bin
    $ cmake ../src
    $ cmake --build .
