Basic CMake usage

<https://codingnest.com/basic-cmake/>

