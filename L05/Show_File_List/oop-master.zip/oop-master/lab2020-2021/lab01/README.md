# Εργαστήριο 1

Δομές και εγγραφές. Κλάσεις και αντικείμενα. Κατασκευαστές (constructors) και καταστροφείς (destructors). Ανάγνωση δεδομένων από αρχείο

* [struct1.cpp](./struct1.cpp)
* [class1.cpp](./class1.cpp)
* [input1.cpp](./input1.cpp)
* [input2.cpp](./input2.cpp)

---

* [input3.cpp](./input3.cpp)
* [input4.cpp](./input4.cpp)